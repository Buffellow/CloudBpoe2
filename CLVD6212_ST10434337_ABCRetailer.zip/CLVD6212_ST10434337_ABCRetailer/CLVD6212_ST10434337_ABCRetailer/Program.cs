using CLVD6212_ST10434337_ABCRetailer.Services;

namespace CLVD6212_ST10434337_ABCRetailer
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);
            // Config
            var config = builder.Configuration;
            
            // Add services to the container.
            builder.Services.AddControllersWithViews();

            // register TableStorage with singlton config //(IIE Emeris School of Computer Science, 2025)
            builder.Services.AddSingleton(new TableStorageService(config.GetConnectionString("AzureStorage")));

            // register Blob Storage with singlton config //(IIE Emeris School of Computer Science, 2025)
            builder.Services.AddSingleton(new BlobService(config.GetConnectionString("AzureStorage")));

            var app = builder.Build();

            // Configure the HTTP request pipeline.
            if (!app.Environment.IsDevelopment())
            {
                app.UseExceptionHandler("/Home/Error");
                // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
                app.UseHsts();
            }

            app.UseHttpsRedirection();
            app.UseStaticFiles();

            app.UseRouting();

            app.UseAuthorization();

            app.MapControllerRoute(
                name: "default",
                pattern: "{controller=Home}/{action=Index}/{id?}");

            app.Run();
        }
    }
}
