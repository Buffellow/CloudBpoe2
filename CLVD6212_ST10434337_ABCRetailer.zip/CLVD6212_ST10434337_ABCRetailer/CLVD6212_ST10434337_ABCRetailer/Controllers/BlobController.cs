﻿using Azure;
using Azure.Data.Tables;
using Azure.Storage.Blobs;
using Azure.Storage.Blobs.Models;
using CLVD6212_ST10434337_ABCRetailer.Models;
using CLVD6212_ST10434337_ABCRetailer.Services;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace CLVD6212_ST10434337_ABCRetailer.Controllers
{
    public class BlobController : Controller
    {
        /// <summary>
        /// Use Service now, for marks, debloat, and functions simplicity
        /// </summary>
        private readonly TableStorageService _tableStorageService;
        private readonly BlobService _blobService;
        private readonly string[] _allowedExtensions = { ".jpg", ".jpeg", ".png", ".mp4", ".mov" }; // Allowed file types

        public BlobController(TableStorageService tableStorageService, BlobService blobService)
        {
            _tableStorageService = tableStorageService;
            _blobService = blobService;
        }

        // Show all blobs uploaded (metadata comes from Table Storage)
        public async Task<IActionResult> Index()//(IIEVC School of Computer Science. 2025) & (IIE Emeris School of Computer Science, 2025)
        {
            try
            {
                // Use Table service to index all BlobMetaData Records
                var blobitems = await _tableStorageService.GetAllBlobMetaDataAsync();
                return View(blobitems);
            }
            catch (Exception ex)
            {
                ViewBag.ErrorMessage = $"Error retrieving blobs: {ex.Message}";
                return View(new List<BlobMetadataModel>());
            }
        }

        // GET: Upload form
        [HttpGet]
        public IActionResult Upload()
        {
            return View();
        }

        // POST: Uploads a new file to Blob Storage and logs metadata
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Upload(IFormFile file, BlobMetadataModel model)//(IIEVC School of Computer Science. 2025) // Convert filename to BlobDataModel
        {
            // Validation checks
            #region Validation Checks
            //Validate Exists
            if (file == null || file.Length == 0)//(Microsoft, 2024)
            {
                ModelState.AddModelError("", "Please select a file to upload.");
                return View();
            }
            // Validate Size
            if (file.Length > 50 * 1024 * 1024) // Limit to 50MB - //(Microsoft, 2024)
            {
                ModelState.AddModelError("", "File size exceeds 50MB limit.");
                return View();
            }

            // Validate extension
            string extension = Path.GetExtension(file.FileName).ToLowerInvariant();//(Microsoft, 2024)
            if (!_allowedExtensions.Contains(extension))
            {
                ModelState.AddModelError("", "Only .jpg, .jpeg, .png, .mp4, and .mov files are allowed.");
                return View();
            }

            // If user didn’t specify a custom name, use original filename
            if (string.IsNullOrEmpty(model.FileName))
            {
                model.FileName = Path.GetFileNameWithoutExtension(file.FileName);//(Microsoft, 2024)
            }
            model.FileName = $"{model.FileName}{extension}";// Ensure file extension is added
            #endregion
            try
            {
                // Upload file to blob
                using var stream = file.OpenReadStream();
                var imageURL = await _blobService.UploadBlobAsync(stream, model.FileName);
                //Assign URL
                model.BlobUrl = imageURL;
               
                // Set Meta Data as
                var metadata = new BlobMetadataModel//(Microsoft, 2024) 
                {
                    FileName = model.FileName,
                    BlobUrl = model.BlobUrl.ToString(),
                    ContentType = file.ContentType,
                    UploadTime = DateTime.UtcNow.AddHours(2),//Add hours to get to GMT +2 for RSA
                    PartitionKey = "BlobMetadata",
                    RowKey = Guid.NewGuid().ToString()
                };

                // Uplaod to Table
                await _tableStorageService.AddBlobMetaDataAsync(metadata);                

                // Success Feedback 
                TempData["SuccessMessage"] = "File uploaded successfully!";
                return RedirectToAction(nameof(Index));
            }
            catch (Exception ex)
            {
                ModelState.AddModelError("", $"Error uploading file: {ex.Message}");
                return View();
            }
        }
        
    
        
    }
}