﻿using Azure.Data.Tables;
using CLVD6212_ST10434337_ABCRetailer.Models;
using CLVD6212_ST10434337_ABCRetailer.Services;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace CLVD6212_ST10434337_ABCRetailer.Controllers
{
    public class ProductController : Controller
    {
        /// <summary>
        /// Use Service now, for marks, debloat, and functions simplicity
        /// </summary>
        private readonly TableStorageService _tableStorageService;

        public ProductController(TableStorageService tableStorageService)
        {
            _tableStorageService = tableStorageService;
        }

        // Show all products
        public async Task<IActionResult> Index()//(Jindal, 2024) & (IIE Emeris School of Computer Science, 2025)
        {
            try
            {
                // Used Service 
                var products = await _tableStorageService.GetAllProductsAsync();
                return View(products);
            }
            catch (Exception ex)
            {
                TempData["ErrorMessage"] = $"Error retrieving products: {ex.Message}";
                return View(new List<ProductModel>());
            }
        }

        // GET: Create form
        public IActionResult Create()
        {
            return View();
        }

        // POST: Create new product //(IIE Emeris School of Computer Science, 2025)
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(ProductModel product)//(Jindal, 2024)
        {
            if (!ModelState.IsValid)
            {
                return View(product); // Return form with validation errors
            }

            try
            {
                // Save to table storage
                await _tableStorageService.AddProductAsync(product); //(Microsoft, 2024)
                TempData["SuccessMessage"] = "Product created successfully!";
                return RedirectToAction(nameof(Index));
            }
            catch (Exception ex)
            {
                ModelState.AddModelError("", $"Error creating product: {ex.Message}");
                return View(product);
            }
        }
    }
}