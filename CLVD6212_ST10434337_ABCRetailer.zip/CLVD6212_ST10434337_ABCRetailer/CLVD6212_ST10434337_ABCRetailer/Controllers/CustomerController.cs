﻿using Azure.Data.Tables;
using CLVD6212_ST10434337_ABCRetailer.Models;
using CLVD6212_ST10434337_ABCRetailer.Services;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace CLVD6212_ST10434337_ABCRetailer.Controllers
{
    public class CustomerController : Controller
    {
        /// <summary>
        /// Use Service now, for marks, debloat, and functions simplicity
        /// </summary>
        private readonly TableStorageService _tableStorageService;

        public CustomerController(TableStorageService tableStorageService)
        {
            _tableStorageService = tableStorageService;
        }

        // Show list of customers
        public async Task<IActionResult> Index() //(IIE Emeris School of Computer Science, 2025)
        {
            try
            {
                // Used Service 
                var customers = await _tableStorageService.GetAllCustomersAsync();
                return View(customers);
            }
            catch (Exception ex)
            {
                TempData["ErrorMessage"] = $"Error retrieving customers: {ex.Message}";
                return View(new List<CustomerModel>());
            }
        }

        // GET: Create form
        [HttpGet]
        public IActionResult Create()
        {
            return View();
        }

        // POST: Create new customer //(IIE Emeris School of Computer Science, 2025)
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(CustomerModel customer)//(Jindal, 2024) & (IIE Emeris School of Computer Science, 2025)
        {
            if (!ModelState.IsValid)
            {
                return View(customer); // Return with validation errors
            }

            try
            {
                // Save to table storage
                await _tableStorageService.AddCustomberAsync(customer); //(Microsoft, 2024)
                TempData["SuccessMessage"] = "Customer created successfully!";
                return RedirectToAction(nameof(Index));
            }
            catch (Exception ex)
            {
                ModelState.AddModelError("", $"Error creating customer: {ex.Message}");
                return View(customer);
            }
        }
    }
}