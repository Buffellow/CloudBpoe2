﻿using Azure;
using Azure.Data.Tables;
using Azure.Storage.Files.Shares;
using Azure.Storage.Files.Shares.Models;
using CLVD6212_ST10434337_ABCRetailer.Models;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace CLVD6212_ST10434337_ABCRetailer.Controllers
{
    public class FileShareController : Controller
    {
        private readonly ShareClient _shareClient; // File Share client
        private readonly ShareDirectoryClient _directoryClient; // Root directory client
        private readonly TableClient _tableClient; // Metadata table for file records
        private readonly IConfiguration _config;
        private readonly string[] _allowedExtensions = { ".pdf", ".docx", ".doc" }; // Allowed file types

        public FileShareController(IConfiguration config)
        {
            _config = config;

            string connectionString = config.GetConnectionString("AzureStorage");

            // Connect to Azure File Share named "contracts"
            _shareClient = new ShareClient(connectionString, "contracts");
            _shareClient.CreateIfNotExists();

            // Work with root directory
            _directoryClient = _shareClient.GetRootDirectoryClient();

            // Connect to FileMetadata table
            _tableClient = new TableClient(connectionString, "FileMetadata");
            _tableClient.CreateIfNotExists();
        }

        // Show all uploaded file metadata
        public async Task<IActionResult> Index()
        {
            try
            {
                var files = new List<FileMetadataModel>();

                // Query file metadata from table storage
                await foreach (var entity in _tableClient.QueryAsync<FileMetadataModel>(filter: $"PartitionKey eq 'FileMetadata'"))
                {
                    files.Add(entity);
                }
                return View(files);
            }
            catch (Exception ex)
            {
                ViewBag.ErrorMessage = $"Error retrieving files: {ex.Message}";
                return View(new List<FileMetadataModel>());
            }
        }

        // GET: Upload form
        public IActionResult Upload()
        {
            return View();
        }

        // POST: Upload file to Azure File Share
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Upload(IFormFile file, string fileName)//(Microsoft, 2025)
        {
            // Validation checks
            if (file == null || file.Length == 0)//(Microsoft, 2024)
            {
                ModelState.AddModelError("", "Please select a file to upload.");
                return View();
            }

            if (file.Length > 50 * 1024 * 1024) // Limit to 50MB //(Microsoft, 2024)
            {
                ModelState.AddModelError("", "File size exceeds 50MB limit.");
                return View();
            }

            // Validate extension
            string extension = Path.GetExtension(file.FileName).ToLowerInvariant();//(Microsoft, 2024)
            if (!_allowedExtensions.Contains(extension))
            {
                ModelState.AddModelError("", "Only .pdf, .docx, and .doc files are allowed.");
                return View();
            }

            // Default filename if not specified
            if (string.IsNullOrEmpty(fileName))
            {
                fileName = Path.GetFileNameWithoutExtension(file.FileName);
            }
            fileName = $"{fileName}{extension}";

            try
            {
                // Upload file to Azure File Share
                var fileClient = _directoryClient.GetFileClient(fileName);//(Microsoft, 2024)
                using (var stream = file.OpenReadStream())
                {
                    await fileClient.CreateAsync(file.Length);
                    await fileClient.UploadAsync(stream);
                }

                // Save metadata into Table Storage
                var metadata = new FileMetadataModel//(Microsoft, 2024)
                {
                    FileName = fileName,
                    FileUrl = fileClient.Uri.ToString(),
                    ContentType = file.ContentType,// From IFormFile
                    UploadTime = DateTime.UtcNow.AddHours(2), //Add hours to get to GMT +2 for RSA
                    PartitionKey = "FileMetadata",
                    RowKey = Guid.NewGuid().ToString()
                };

                await _tableClient.AddEntityAsync(metadata);

                // Log Upload
                var logger = new Helpers.QueueLogger(_config.GetConnectionString("AzureStorage"));
                await logger.AddMsg($"FileShare '{metadata.FileName}' uploaded by a user at {metadata.UploadTime}");//(Microsoft, 2025)

                TempData["SuccessMessage"] = "File uploaded successfully!";
                return RedirectToAction(nameof(Index));
            }
            catch (Exception ex)
            {
                ModelState.AddModelError("", $"Error uploading file: {ex.Message}");
                return View();
            }
        }

        // GET: Download file from File Share
        public async Task<IActionResult> Download(string rowKey)
        {
            try
            {
                // Get metadata by rowKey
                var response = await _tableClient.GetEntityAsync<FileMetadataModel>("FileMetadata", rowKey);
                var entity = response.Value;
                if (entity == null)
                {
                    return NotFound();
                }

                // Locate file in Azure File Share
                var fileClient = _directoryClient.GetFileClient(entity.FileName);
                if (!await fileClient.ExistsAsync())
                {
                    return NotFound();
                }

                // Download file stream
                var downloadInfo = await fileClient.DownloadAsync();

                // Log Upload action
                var logger = new Helpers.QueueLogger(_config.GetConnectionString("AzureStorage"));
                await logger.AddMsg($"FileShare '{entity.FileName}' uploaded by a user at {entity.UploadTime}");//(Microsoft, 2025)


                return File(downloadInfo.Value.Content, entity.ContentType, entity.FileName);
            }
            catch (Exception ex)
            {
                TempData["ErrorMessage"] = $"Error downloading file: {ex.Message}";
                return RedirectToAction(nameof(Index));
            }
        }
    }
}