﻿using Azure;
using Azure.Data.Tables;
using System.ComponentModel.DataAnnotations;
using System.Runtime.Serialization;

namespace CLVD6212_ST10434337_ABCRetailer.Models
{
    public enum ContactMethod
    {
        Email,
        Phone,
        SMS
    }
    public class CustomerModel : ITableEntity
    {
        // Table storage required props
        [Required]
        public string PartitionKey { get; set; } = "Customer";

        [Required]
        public string RowKey { get; set; } = Guid.NewGuid().ToString();

        [IgnoreDataMember] // not used in form binding/display
        public DateTimeOffset? Timestamp { get; set; }

        [IgnoreDataMember]
        public ETag ETag { get; set; }

        // UI fields with validation/display metadata
        [Display(Name = "Name")]
        [Required(ErrorMessage = "Name is required")]
        public string Name { get; set; }

        [Display(Name = "Surname")]
        [Required(ErrorMessage = "Surname is required")]
        public string Surname { get; set; }

        [Display(Name = "Email")]
        [Required(ErrorMessage = "Email is required")]
        [EmailAddress(ErrorMessage = "Invalid email address")]
        public string Email { get; set; }

        [Display(Name = "Phone")]
        [Required(ErrorMessage = "Phone is required")]
        [Phone(ErrorMessage = "Invalid phone number")]
        public string Phone { get; set; }

        [Display(Name = "Preferred Contact Method")]
        [Required(ErrorMessage = "Contact method is required")]
        public ContactMethod PreferredContact { get; set; } = ContactMethod.Email;

        [Display(Name = "Address")]
        [Required(ErrorMessage = "Address is required")]
        public string Address { get; set; } 

        public DateTime CreatedDate { get; set; } =  DateTime.UtcNow.AddHours(2); // Default SAST time - for debug
        
        public CustomerModel()
        {
            PartitionKey = "Customer";
            RowKey = Guid.NewGuid().ToString();
            CreatedDate = DateTime.UtcNow;
        }
    }
}