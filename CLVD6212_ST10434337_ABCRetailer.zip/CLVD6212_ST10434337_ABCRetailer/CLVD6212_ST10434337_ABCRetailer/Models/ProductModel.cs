﻿using Azure;
using Azure.Data.Tables;
using System.ComponentModel.DataAnnotations;

namespace CLVD6212_ST10434337_ABCRetailer.Models
{
    public class ProductModel : ITableEntity
    {
        // Manditory
        [Required]
        public string PartitionKey { get; set; } = "Product";
        [Required]
        public string RowKey { get; set; } = Guid.NewGuid().ToString();
        // Last Modified time
        public DateTimeOffset? Timestamp { get; set; } = DateTime.UtcNow.AddHours(2); // UTC time to avoid azure error 
        public ETag ETag { get; set; }

        // Added 
        [Display(Name = "Title")]
        [Required(ErrorMessage = "Product title is required")]
        public string Title { get; set; }

        [Display(Name = "Description")]
        [Required(ErrorMessage = "Description is required")]
        public string Description { get; set; }

        [Display(Name = "Quantity")]
        [Required(ErrorMessage = "Quantity is required")]
        [Range(0, int.MaxValue, ErrorMessage = "Quantity must be a non-negative number")]
        public int Qty { get; set; }

        [Display(Name = "Price per item")]
        [Required(ErrorMessage = "Price is required")]
        [Range(0.01, double.MaxValue, ErrorMessage = "Price must be greater than zero")]
        public double Price { get; set; }
                
        [Display(Name = "Image/Video")]
        public double ImageURL{ get; set; }

        public DateTime CreatedDate { get; set; } = DateTime.UtcNow.AddHours(2); // Added CreatedDate property

        public ProductModel()
        {
            PartitionKey = "Product";
            RowKey = Guid.NewGuid().ToString();
            CreatedDate = DateTime.UtcNow.AddHours(2); 
        }
    }
}
