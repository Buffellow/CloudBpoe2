﻿using Azure;
using Azure.Data.Tables;
using System;
using System.ComponentModel.DataAnnotations;

namespace CLVD6212_ST10434337_ABCRetailer.Models
{
    public class FileMetadataModel : ITableEntity
    {
        [Required(ErrorMessage = "File name is required")]
        public string FileName { get; set; }
        [Required(ErrorMessage = "File URL is required")]
        public string FileUrl { get; set; }
        public DateTime UploadTime { get; set; }
        [Required(ErrorMessage = "Content type is required")]
        public string ContentType { get; set; } //(Microsoft, 2024)
        public string PartitionKey { get; set; }
        public string RowKey { get; set; }
        public DateTimeOffset? Timestamp { get; set; }
        public ETag ETag { get; set; }

        public FileMetadataModel()
        {
            PartitionKey = "FileMetadata";
            RowKey = Guid.NewGuid().ToString();
            UploadTime = DateTime.UtcNow;
        }
    }
}