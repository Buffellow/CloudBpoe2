﻿using Azure.Data.Tables;
using CLVD6212_ST10434337_ABCRetailer.Models;

namespace CLVD6212_ST10434337_ABCRetailer.Services
{
    public class TableStorageService
    {
        /// <summary>
        /// Created Services as required, think thats how I lost marks last time...
        /// But mainly to for simplify functions 
        /// later rename blob to blobItem
        /// </summary>
        public readonly TableClient _productTableClient;
        public readonly TableClient _customerTableClient;
        public readonly TableClient _blobMetaDataTableClient;
        public TableStorageService(string connectionString) //(IIE Emeris School of Computer Science, 2025)
        {
            // Connect and Create
            _customerTableClient = new TableClient(connectionString, "tblCustomer");
            _customerTableClient.CreateIfNotExistsAsync().Wait();
            _productTableClient = new TableClient(connectionString, "tblProduct");
            _productTableClient.CreateIfNotExistsAsync().Wait();
            _blobMetaDataTableClient = new TableClient(connectionString, "tblBlobMetaData");
            _blobMetaDataTableClient.CreateIfNotExistsAsync().Wait();
        }
        
        // Get all Customers Service
        public async Task<List<CustomerModel>> GetAllCustomersAsync()//(IIE Emeris School of Computer Science, 2025)
        {
            var customers = new List<CustomerModel>();
            await foreach (var aCustomer in _customerTableClient.QueryAsync<CustomerModel>())
            {
                customers.Add(aCustomer);
            }
            return customers;
        }
        // Get all Products Service
        public async Task<List<ProductModel>> GetAllProductsAsync()//(IIE Emeris School of Computer Science, 2025)
        {
            var products = new List<ProductModel>();
            await foreach (var aProduct in _productTableClient.QueryAsync<ProductModel>())
            {
                products.Add(aProduct);
            }
            return products;
        }
        // Get all BlobMetaData Service
        public async Task<List<BlobMetadataModel>> GetAllBlobMetaDataAsync()//(IIE Emeris School of Computer Science, 2025)
        {
            var blobs = new List<BlobMetadataModel>();
            await foreach (var aBlobItem in _blobMetaDataTableClient.QueryAsync<BlobMetadataModel>())
            {
                blobs.Add(aBlobItem);
            }
            return blobs;
        }

        // ADDED: New method to retrieve single blob metadata by RowKey
        // Used in ViewFile action to get specific blob details
        public async Task<BlobMetadataModel> GetBlobMetaDataByRowKeyAsync(string rowKey)
        {
            // Retrieve entity from table using PartitionKey and RowKey
            var response = await _blobMetaDataTableClient.GetEntityAsync<BlobMetadataModel>("BlobMetadata", rowKey);
            return response.Value;
        }



        // Add a Customer to table
        public async Task AddCustomberAsync(CustomerModel customer)//(IIE Emeris School of Computer Science, 2025)
        {
            if (string.IsNullOrEmpty(customer.PartitionKey) || string.IsNullOrEmpty(customer.RowKey))
            {
                throw new ArgumentException("PratitionKey and RowKey must be set.");
            }
            try
            {
                // Save to Table
                await _customerTableClient.AddEntityAsync(customer);
            }
            catch (Exception ex)
            {
                throw new InvalidOperationException("Error with adding the customer to the table storage", ex);
            }
        }
        // Add a Product to table
        public async Task AddProductAsync(ProductModel product)//(IIE Emeris School of Computer Science, 2025)
        {
            if (string.IsNullOrEmpty(product.PartitionKey) || string.IsNullOrEmpty(product.RowKey))
            {
                throw new ArgumentException("PratitionKey and RowKey must be set.");
            }
            try
            {
                // Save to Table
                await _productTableClient.AddEntityAsync(product);
            }
            catch (Exception ex)
            {
                throw new InvalidOperationException("Error with adding the product to the table storage", ex);
            }
        }
        // Add BlobMetaData record to table
        public async Task AddBlobMetaDataAsync(BlobMetadataModel blobData)//(IIE Emeris School of Computer Science, 2025)
        {
            if (string.IsNullOrEmpty(blobData.PartitionKey) || string.IsNullOrEmpty(blobData.RowKey))
            {
                throw new ArgumentException("PratitionKey and RowKey must be set.");
            }
            try
            {
                // Save to Table
                await _blobMetaDataTableClient.AddEntityAsync(blobData);
            }
            catch (Exception ex)
            {
                throw new InvalidOperationException("Error with adding the Blob Meta Data to the table storage", ex);
            }
        }
       
        // Delete a Customer from the table, implement later for all
        public async Task DeleteCustomerAsync(string partitionKey, string rowKey)//(IIE Emeris School of Computer Science, 2025)
        {
            await _customerTableClient.DeleteEntityAsync(partitionKey, rowKey);
        }

        // Delete a Product from the table
        public async Task DeleteProductAsync(string partitionKey, string rowKey)//(IIE Emeris School of Computer Science, 2025)
        {
            await _productTableClient.DeleteEntityAsync(partitionKey, rowKey);
        }
        // Delete BlobData from the table
        public async Task DeleteBlobMetaDataAsync(string partitionKey, string rowKey)//(IIE Emeris School of Computer Science, 2025)
        {
            await _blobMetaDataTableClient.DeleteEntityAsync(partitionKey, rowKey);
        }
      
    }
}
