﻿using Azure;
using Azure.Storage.Blobs;
using Azure.Storage.Blobs.Models;

namespace CLVD6212_ST10434337_ABCRetailer.Services
{
    public class BlobService
    {
        private readonly BlobServiceClient _blobServiceClient;
        private readonly BlobContainerClient _containerClient;
        private readonly string _ContainerName = "blobs";

        public BlobService(string connectionString)
        {
            _blobServiceClient = new BlobServiceClient(connectionString);
            // Connect to blob storage container, create if not exists
            _containerClient = _blobServiceClient.GetBlobContainerClient(_ContainerName);
            _containerClient.CreateIfNotExists(PublicAccessType.Blob);
             
        }
        
        // List all blobs via Table with data from their ModelType :)

        // Upload A blob file
        public async Task<string> UploadBlobAsync(Stream fileStream, string fileName) //(IIE Emeris School of Computer Science, 2025)
        {
            //What container
            var containerClient = _blobServiceClient.GetBlobContainerClient(_ContainerName);
            //Which File
            var blobClient = containerClient.GetBlobClient(fileName);
            //Upload
            await blobClient.UploadAsync(fileStream);
            //Return URI/url location of blob
            return blobClient.Uri.ToString();
        }


        // Delete a Blob File, implement later
        public async Task DeleteBlobAsync(string blobUri) //(IIE Emeris School of Computer Science, 2025)
        {
            Uri uri = new Uri(blobUri);
            //Extract blob name from URI by taking the last segment path 
            string blobName = uri.Segments[^1];
            //What container
            var containerClient = _blobServiceClient.GetBlobContainerClient(_ContainerName);
            //Which File
            var blobClient = containerClient.GetBlobClient(blobName);
            //Delete
            await blobClient.DeleteIfExistsAsync(DeleteSnapshotsOption.IncludeSnapshots);
        }


        // Download Blob Item 
        

    }
}
