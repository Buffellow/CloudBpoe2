﻿using Azure.Data.Tables;
using CLDV6212_ST10434337_Part1.Models;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace CLDV6212_ST10434337_Part1.Controllers
{
    public class ProductController : Controller
    {
        private readonly TableClient _tableClient; // Table client for products
        private readonly IConfiguration _config;

        public ProductController(IConfiguration config)
        {
            _config = config;

            string connectionString = config.GetConnectionString("AzureStorage");
            if (string.IsNullOrEmpty(connectionString))
            {
                throw new ArgumentNullException(nameof(connectionString), "AzureStorage connection string is missing.");
            }

            // Connect to Products table
            _tableClient = new TableClient(connectionString, "Products2");// troubleshooting was Products ... but was still deleting 
            _tableClient.CreateIfNotExists();
        }

        // Show all products
        public async Task<IActionResult> Index()//(Jindal, 2024)
        {
            try
            {
                var products = new List<ProductModel>();

                // Query table for product entities
                await foreach (var product in _tableClient.QueryAsync<ProductModel>())
                {
                    products.Add(product);
                }
                return View(products);
            }
            catch (Exception ex)
            {
                TempData["ErrorMessage"] = $"Error retrieving products: {ex.Message}";
                return View(new List<ProductModel>());
            }
        }

        // GET: Create form
        public IActionResult Create()
        {
            return View();
        }

        // POST: Create new product
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(ProductModel product)//(Jindal, 2024)
        {
            if (!ModelState.IsValid)
            {
                return View(product); // Return form with validation errors
            }

            try
            {
                // Set table keys
                product.PartitionKey = "Product"; 
                product.RowKey = Guid.NewGuid().ToString(); 
                product.CreatedDate = DateTime.UtcNow.AddHours(2); // SAST 

                // Add entity to table storage
                await _tableClient.AddEntityAsync(product);
                
                // Log the action to Queue Storage
                var logger = new Helpers.QueueLogger(_config.GetConnectionString("AzureStorage"));
                await logger.AddMsg($"{product.PartitionKey} of ID:{product.RowKey} was created at {product.CreatedDate.ToString()}");//(Microsoft, 2025)


                TempData["SuccessMessage"] = "Product created successfully!";
                return RedirectToAction(nameof(Index));
            }
            catch (Exception ex)
            {
                ModelState.AddModelError("", $"Error creating product: {ex.Message}");
                return View(product);
            }
        }
    }
}