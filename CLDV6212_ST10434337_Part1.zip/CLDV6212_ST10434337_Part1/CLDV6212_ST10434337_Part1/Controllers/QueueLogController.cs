﻿using Azure.Storage.Queues;
using Microsoft.AspNetCore.Mvc;

namespace CLDV6212_ST10434337_Part1.Controllers
{
    public class QueueLogController : Controller
    {
        private readonly QueueClient _queueClient; // Queue client for logs

        public QueueLogController(IConfiguration config)
        {
            string connectionString = config.GetConnectionString("AzureStorage");

            // Connect to logsqueue
            _queueClient = new QueueClient(connectionString, "logsqueue");
            _queueClient.CreateIfNotExists();
        }

        // GET: View top 20 log messages (Peek)
        public async Task<IActionResult> Index()//(Microsoft, 2025)
        {
            var messages = new List<string>();

            try
            {
                // Peek top 20 messages - does not remove them from queue
                var peeked = await _queueClient.PeekMessagesAsync(maxMessages: 20);
                foreach (var msg in peeked.Value)
                {
                    messages.Add(msg.MessageText);
                }
            }
            catch (Exception ex)
            {
                messages.Add($"Error: {ex.Message}");
            }

            return View(messages);
        }

    }
}
