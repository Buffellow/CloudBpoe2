﻿using Azure.Data.Tables;
using CLDV6212_ST10434337_Part1.Models;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace CLDV6212_ST10434337_Part1.Controllers
{
    public class CustomerController : Controller
    {
        private readonly TableClient _tableClient; // Table client for Customers table
        private readonly IConfiguration _config;

        public CustomerController(IConfiguration config)
        {
            _config = config;

            string connectionString = config.GetConnectionString("AzureStorage");

            // Make sure connection string exists
            if (string.IsNullOrEmpty(connectionString))
            {
                throw new ArgumentNullException(nameof(connectionString), "AzureStorage connection string is missing.");
            }

            // Connect to Customers table - Customers3 used for debug
            _tableClient = new TableClient(connectionString, "Customers3");//(Jindal, 2024) 
            _tableClient.CreateIfNotExists();
        }

        // Show list of customers
        public async Task<IActionResult> Index()
        {
            try//(Jindal, 2024)
            {
                var customers = new List<CustomerModel>();
                // Query all customers from table storage
                await foreach (var customer in _tableClient.QueryAsync<CustomerModel>()) //(Microsoft, 2024)
                {
                    customers.Add(customer);
                }
                return View(customers);
            }
            catch (Exception ex)
            {
                TempData["ErrorMessage"] = $"Error retrieving customers: {ex.Message}";
                return View(new List<CustomerModel>());
            }
        }

        // GET: Create form
        [HttpGet]
        public IActionResult Create()
        {
            return View();
        }

        // POST: Create new customer
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(CustomerModel customer)//(Jindal, 2024)
        {
            if (!ModelState.IsValid)
            {
                return View(customer); // Return with validation errors
            }

            try
            {
                // Set Table Storage keys
                customer.PartitionKey = "Customer";
                customer.RowKey = Guid.NewGuid().ToString();
                customer.CreatedDate = DateTime.UtcNow.AddHours(2); // add 2 hours for SAST

                // Save to table storage
                await _tableClient.AddEntityAsync(customer); //(Microsoft, 2024)

                // Log the action to Queue Storage
                var logger = new Helpers.QueueLogger(_config.GetConnectionString("AzureStorage"));
                await logger.AddMsg($"{customer.PartitionKey} of ID:{customer.RowKey} was created at {customer.CreatedDate.ToString()}");//(Microsoft, 2025)


                TempData["SuccessMessage"] = "Customer created successfully!";
                return RedirectToAction(nameof(Index));
            }
            catch (Exception ex)
            {
                ModelState.AddModelError("", $"Error creating customer: {ex.Message}");
                return View(customer);
            }
        }
    }
}