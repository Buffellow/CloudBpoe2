﻿using Azure;
using Azure.Data.Tables;
using Azure.Storage.Blobs;
using Azure.Storage.Blobs.Models;
using CLDV6212_ST10434337_Part1.Models;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace CLDV6212_ST10434337_Part1.Controllers
{
    public class BlobController : Controller
    {
        private readonly BlobContainerClient _container; // Client to interact with Blob storage
        private readonly TableClient _tableClient; // Client to interact with Blob storage
        private readonly IConfiguration _config;
        private readonly string[] _allowedExtensions = { ".jpg", ".jpeg", ".png", ".mp4", ".mov" }; // Allowed file types

        public BlobController(IConfiguration config)
        {
            _config = config;
            string connectionString = config.GetConnectionString("AzureStorage");

            // Connect to Blob Storage container named "multimedia", create if not exist with blob access
            _container = new BlobContainerClient(connectionString, "multimedia");
            _container.CreateIfNotExists(PublicAccessType.Blob);

            // Connect to Table Storage table for blob metadata
            _tableClient = new TableClient(connectionString, "BlobMetadata");
            _tableClient.CreateIfNotExists();
        }

        // Show all blobs uploaded (metadata comes from Table Storage)
        public async Task<IActionResult> Index()//(IIEVC School of Computer Science. 2025)
        {
            try
            {
                var blobs = new List<BlobMetadataModel>();

                // Query table storage for all blob metadata records
                await foreach (var entity in _tableClient.QueryAsync<BlobMetadataModel>(filter: $"PartitionKey eq 'BlobMetadata'"))
                {
                    blobs.Add(entity);
                }
                return View(blobs);
            }
            catch (Exception ex)
            {
                ViewBag.ErrorMessage = $"Error retrieving blobs: {ex.Message}";
                return View(new List<BlobMetadataModel>());
            }
        }

        // GET: Upload form
        public IActionResult Upload()
        {
            return View();
        }

        // POST: Uploads a new file to Blob Storage and logs metadata
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Upload(IFormFile file, string fileName)//(IIEVC School of Computer Science. 2025)
        {
            // Validation checks
            if (file == null || file.Length == 0)//(Microsoft, 2024)
            {
                ModelState.AddModelError("", "Please select a file to upload.");
                return View();
            }

            if (file.Length > 50 * 1024 * 1024) // Limit to 50MB - //(Microsoft, 2024)
            {
                ModelState.AddModelError("", "File size exceeds 50MB limit.");
                return View();
            }

            // Validate extension
            string extension = Path.GetExtension(file.FileName).ToLowerInvariant();//(Microsoft, 2024)
            if (!_allowedExtensions.Contains(extension))
            {
                ModelState.AddModelError("", "Only .jpg, .jpeg, .png, .mp4, and .mov files are allowed.");
                return View();
            }

            // If user didn’t specify a custom name, use original filename
            if (string.IsNullOrEmpty(fileName))
            {
                fileName = Path.GetFileNameWithoutExtension(file.FileName);//(Microsoft, 2024)
            }
            fileName = $"{fileName}{extension}";// Ensure file extension is added

            try
            {
                // Create BlobClient for this file
                var blobClient = _container.GetBlobClient(fileName);

                // Assign ContentType so view can put in correct form to view
                var blobHttpHeaders = new BlobHttpHeaders
                {
                    ContentType = file.ContentType
                };

                // Upload file stream
                using (var stream = file.OpenReadStream())
                {
                    await blobClient.UploadAsync(stream, new BlobUploadOptions { HttpHeaders = blobHttpHeaders }, default); //(Microsoft, 2024)
                }

                // Save metadata about this blob into Table Storage
                var metadata = new BlobMetadataModel//(Microsoft, 2024) 
                {
                    FileName = fileName,
                    BlobUrl = blobClient.Uri.ToString(),
                    ContentType = file.ContentType,
                    UploadTime = DateTime.UtcNow.AddHours(2),//Add hours to get to GMT +2 for RSA
                    PartitionKey = "BlobMetadata",
                    RowKey = Guid.NewGuid().ToString()
                };

                await _tableClient.AddEntityAsync(metadata);

                // Log Upload
                var logger = new Helpers.QueueLogger(_config.GetConnectionString("AzureStorage"));
                await logger.AddMsg($"Blob '{metadata.FileName}' uploaded by a user at {metadata.UploadTime}");//(Microsoft, 2025)

                TempData["SuccessMessage"] = "File uploaded successfully!";
                return RedirectToAction(nameof(Index));
            }
            catch (Exception ex)
            {
                ModelState.AddModelError("", $"Error uploading file: {ex.Message}");
                return View();
            }
        }

        // GET: View details of a file from metadata
        public async Task<IActionResult> ViewFile(string rowKey)//(IIEVC School of Computer Science. 2025)
        {
            try
            {
                // Retrieve metadata by RowKey
                var response = await _tableClient.GetEntityAsync<BlobMetadataModel>("BlobMetadata", rowKey);
                var entity = response.Value; // Extract the BlobMetadataModel from Response
                if (entity == null)
                {
                    return NotFound();
                }
                return View(entity);
            }
            catch (Exception ex)
            {
                TempData["ErrorMessage"] = $"Error retrieving file: {ex.Message}";
                return RedirectToAction(nameof(Index));
            }
        }

        // GET: Download file from Blob Storage
        public async Task<IActionResult> Download(string rowKey)//(IIEVC School of Computer Science. 2025)
        {
            try
            {
                // Fetch metadata first
                var response = await _tableClient.GetEntityAsync<BlobMetadataModel>("BlobMetadata", rowKey);
                var entity = response.Value; // Extract the BlobMetadataModel from Response
                if (entity == null)
                {
                    return NotFound();
                }

                // Get blob reference
                var blobClient = _container.GetBlobClient(entity.FileName);
                if (!await blobClient.ExistsAsync())
                {
                    return NotFound();
                }

                // Download blob stream
                var blobDownloadInfo = await blobClient.DownloadAsync();

                // Log download
                var logger = new Helpers.QueueLogger(_config.GetConnectionString("AzureStorage"));
                await logger.AddMsg($"Blob '{entity.FileName}' downloaded by a user at {DateTime.UtcNow.AddHours(2)}");//(Microsoft, 2025)


                return File(blobDownloadInfo.Value.Content, blobDownloadInfo.Value.ContentType, entity.FileName);
            }
            catch (Exception ex)
            {
                TempData["ErrorMessage"] = $"Error downloading file: {ex.Message}";
                return RedirectToAction(nameof(Index));
            }
        }
    }
}