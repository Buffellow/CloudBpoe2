﻿using Azure.Storage.Queues;

namespace CLDV6212_ST10434337_Part1.Helpers
{
    public class QueueLogger
    {
        private readonly QueueClient _queueClient;
        /// <summary>
        /// Used in Controllers to Log actiion to the logsqueue, recording user interactions. 
        /// </summary>
        public QueueLogger(string connectionString, string queueName = "logsqueue")//(Microsoft, 2025)
        {
            _queueClient = new QueueClient(connectionString, queueName);
            _queueClient.CreateIfNotExists();
        }

        // Add a message to the queue
        public async Task AddMsg(string logText)
        {
            await _queueClient.SendMessageAsync(logText);
            //Debug
            //Console.WriteLine($"[Queue Log] {logText}");
        }
    }
}
