using CLVD6212_ST10434337_ABCRetailer.Models;
using CLVD6212_ST10434337_ABCRetailer.Services;

namespace CLVD6212_ST10434337_ABCRetailer
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);

            // Add services to the container.
            builder.Services.AddControllersWithViews();



            // get connection string from config
            var connectionString = builder.Configuration.GetConnectionString("AzureStorage");//(IIE Emeris School of Computer Science, 2025)

            // Register your generic services as singletons
            //TABLES 
            /*
                AdminModel
                CustomerModel
                ProductModel
                ContractModel
                LogTableModel

                if time implement
                CartModel
                OrdersModel
                OrderItemModel
                
             Each must have ITableEntity
             */
            // for services (IIE Emeris School of Computer Science, 2025)
            builder.Services.AddSingleton<TableStorageService<AdminModel>>(sp =>new TableStorageService<AdminModel>(connectionString, "Admin"));

            builder.Services.AddSingleton<TableStorageService<CustomerModel>>(sp => new TableStorageService<CustomerModel>(connectionString, "Customer"));

            builder.Services.AddSingleton<TableStorageService<ProductModel>>(sp => new TableStorageService<ProductModel>(connectionString, "Product"));

            builder.Services.AddSingleton<TableStorageService<ContractModel>>(sp => new TableStorageService<ContractModel>(connectionString, "Contract"));

            builder.Services.AddSingleton<TableStorageService<LogTableModel>>(sp => new TableStorageService<LogTableModel>(connectionString, "LogTable"));

            builder.Services.AddSingleton<TableStorageService<CartModel>>(sp => new TableStorageService<CartModel>(connectionString, "Cart"));

            builder.Services.AddSingleton<TableStorageService<OrdersModel>>(sp => new TableStorageService<OrdersModel>(connectionString, "Orders"));

            builder.Services.AddSingleton<TableStorageService<OrderItemsModel>>(sp => new TableStorageService<OrderItemsModel>(connectionString, "OrderItems"));

            // BLOB
            // register BlobService
            builder.Services.AddSingleton<BlobService>(sp => new BlobService(connectionString));

            //FILE SHARE
            // Register FileShareService as a singleton
            builder.Services.AddSingleton<FileShareService>(sp => new FileShareService(connectionString));

            //QUEUE
            // Register QueueService as a singleton
            builder.Services.AddSingleton<QueueService>(sp => new QueueService(connectionString));

            // PRODUCT
            // Table + Blob 
            builder.Services.AddScoped<ProductService>();

            //LOG
            builder.Services.AddSingleton<LogService>();
            
            //ORDERs
            builder.Services.AddSingleton<OrderService>();

            var app = builder.Build();

            // Configure the HTTP request pipeline.
            if (!app.Environment.IsDevelopment())
            {
                app.UseExceptionHandler("/Home/Error");
                // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
                app.UseHsts();
            }

            app.UseHttpsRedirection();
            app.UseStaticFiles();

            app.UseRouting();

            app.UseAuthorization();

            app.MapControllerRoute(
                name: "default",
                pattern: "{controller=Home}/{action=Index}/{id?}");

            app.Run();
        }
    }
}
