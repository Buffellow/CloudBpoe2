﻿using CLVD6212_ST10434337_ABCRetailer.Models;
using System.Text.Json;

namespace CLVD6212_ST10434337_ABCRetailer.Services
{
    public class OrderService
    {
        private readonly TableStorageService<OrdersModel> _ordersTable;
        private readonly TableStorageService<CartModel> _cartTable;
        private readonly TableStorageService<OrderItemsModel> _orderItemsTable;
        private readonly QueueService _queueService;
        private readonly LogService _logService;

        public OrderService(
            TableStorageService<OrdersModel> ordersTable,TableStorageService<CartModel> cartTable, TableStorageService<OrderItemsModel> orderItemsTable, QueueService queueService, LogService logService)//(IIE Emeris School of Computer Science, 2025)
        {
            _ordersTable = ordersTable;
            _cartTable = cartTable;
            _orderItemsTable = orderItemsTable;
            _queueService = queueService;
            _logService = logService;
        }

        
        // Converts Customers cart to order with some order items
        // Semd processing msg to queue, clear cart, log the event
        public async Task<string> CreateOrderFromCartAsync(string customerId)
        {
            // GET ALL CART ITEMS, use the queryAsync filter in my service :D
            var cartItems = await _cartTable.QueryAsync($"PartitionKey eq '{customerId}'");
            if (cartItems.Count == 0)
                throw new InvalidOperationException("Cart is empty.");

            // Calc order total
            decimal total = cartItems.Sum(cart => cart.QTY * cart.ItemPriceSnapshot);

            // CREATE ORDER
            // Create unique orderID
            string orderId = Guid.NewGuid().ToString();
            var order = new OrdersModel
            {
                PartitionKey = customerId,
                RowKey = orderId,
                CustomerID = customerId,
                OrderDate = DateTime.UtcNow.AddHours(2),//Add hours to get to GMT +2 for RSA
                Status = OrderStatus.OrderPlaced,
                TotalAmount = total,
                CreatedDate = DateTime.UtcNow.AddHours(2)//Add hours to get to GMT +2 for RSA
            };
            await _ordersTable.AddAsync(order);

            // Create order Items associated to the order by orderId 
            foreach (var cartItem in cartItems)
            {
                var orderItem = new OrderItemsModel
                {
                    PartitionKey = orderId, // Can group items by OrderId
                    RowKey = cartItem.RowKey, // ProductId
                    ProductName = cartItem.ProductNameSnapshot,
                    QTY = cartItem.QTY,
                    ItemPrice = cartItem.ItemPriceSnapshot,
                    TotalAmount = cartItem.ItemTotalAmount
                };
                await _orderItemsTable.AddAsync(orderItem);
            }

            // SEND ORDER TO QUEUE (status changed)
            var msg = JsonSerializer.Serialize(new
            {
                MessageId = Guid.NewGuid().ToString(),
                OrderId = orderId,
                CustomerId = customerId,
                Event = OrderStatus.OrderPlaced.ToString(),
                Payload = new { Total = total },
                Timestamp = DateTime.UtcNow,
                Attempt = 1,
                Actor = "User"

                //OrderId = orderId,
                //CustomerId = customerId,
                //Total = total,
                //EventType = OrderStatus.OrderPlaced.ToString()
            });
            await _queueService.SendMessageAsync("orderprocessing", msg);//Check mataches queueName in Program.cs, it does

            // CLEAR CART
            foreach (var cartItem in cartItems)
            {
                await _cartTable.DeleteAsync(cartItem.PartitionKey, cartItem.RowKey);
            }

            // LOG EVENT . . .WRONG PLACE?
            await _logService.WriteLogAsync(
                orderId,
                OrderStatus.OrderPlaced,
                $"Order {orderId} placed by customer {customerId}.",
                "User"
            );

            return orderId;
        }
    }
}
