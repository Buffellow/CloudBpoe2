﻿using CLVD6212_ST10434337_ABCRetailer.Models;

namespace CLVD6212_ST10434337_ABCRetailer.Services
{
    /// <summary>
    /// Add Products and product image to table
    /// </summary>
    public class ProductService
    {
        private readonly TableStorageService<ProductModel> _productTableService;
        private readonly BlobService _blobService;
        // Default Product Container
        private readonly string _containerName = "product-images";

        public ProductService(TableStorageService<ProductModel> productTableService,BlobService blobService)//(IIE Emeris School of Computer Science, 2025)
        {
            _productTableService = productTableService;
            _blobService = blobService;
        }

        // Add a new product to table, if its file is valid then upload its image/video to Blob 
        public async Task<ProductModel> AddProductAsync(string name,string description,decimal price,int stockQty,Stream? imageStream,string? originalFileName)
        {
            // Generate keys
            string partitionKey = "Product"; // fixed partition for all products
            string rowKey = Guid.NewGuid().ToString(); // unique ID for each product

            // Upload file to Blob if it has been provided
            string? imageUrl = null;
            if (imageStream != null && !string.IsNullOrWhiteSpace(originalFileName))
            {
                // Unique blob name: GUID_originalName
                var blobFileName = $"{Guid.NewGuid()}_{originalFileName}";
                imageUrl = await _blobService.UploadBlobAsync(imageStream, blobFileName, _containerName);
            }

            var product = new ProductModel//(IIE Emeris School of Computer Science, 2025)
            {
                PartitionKey = partitionKey,
                RowKey = rowKey,
                Name = name,
                Description = description,
                Price = price,
                StockQTY = stockQty,
                ImageURL = imageUrl,
                CreatedDate = DateTime.UtcNow.AddHours(2),//Add hours to get to GMT +2 for RSA
            };

            await _productTableService.AddAsync(product);
            return product;
        }

        // Get all Products
        public async Task<List<ProductModel>> GetAllProductsAsync()
        {
            return await _productTableService.GetAllAsync();
        }

        // Get a single product by rowkey (productID)
        public async Task<ProductModel?> GetProductAsync(string rowKey)
        {
            return await _productTableService.GetSingleRecordAsync("Product", rowKey);
        }

        // Delete if Product Exists
        public async Task DeleteProductAsync(string rowKey)
        {
            var product = await GetProductAsync(rowKey);
            if (product != null)
            {
                // delete blob if exists
                if (!string.IsNullOrEmpty(product.ImageURL))
                {
                    var blobFileName = Path.GetFileName(new Uri(product.ImageURL).LocalPath);
                    await _blobService.DeleteBlobAsync(blobFileName, _containerName);
                }

                await _productTableService.DeleteAsync(product.PartitionKey, product.RowKey);
            }
        }
    }
}
