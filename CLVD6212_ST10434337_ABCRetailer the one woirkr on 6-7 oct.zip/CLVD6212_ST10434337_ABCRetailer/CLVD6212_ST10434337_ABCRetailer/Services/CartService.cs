﻿using Azure.Data.Tables;
using CLVD6212_ST10434337_ABCRetailer.Models;

namespace CLVD6212_ST10434337_ABCRetailer.Services
{
    public class CartService
    {
        private readonly TableClient _cartTable;
        private readonly TableClient _productTable;

        public CartService(string connectionString)//(IIE Emeris School of Computer Science, 2025)
        {
            // Initialize Cart Table
            _cartTable = new TableClient(connectionString, "Cart");
            _cartTable.CreateIfNotExists();

            // Initialize Product Table (needed for snapshot lookups)
            _productTable = new TableClient(connectionString, "Product");// Check in Program.cs that is same, it is
            _productTable.CreateIfNotExists();
        }

        // ADD TO CART
        // Add product to cart with snapshot
        // If already exists, update quantity
        public async Task AddToCartAsync(string customerId, string productId, int qty)
        {
            // Lookup product snapshot
            var product = await _productTable.GetEntityAsync<ProductModel>("Product", productId);
            if (product == null)
                throw new Exception("Product not found");// in controller catch for Exception and send relevant feedback

            // Try to get existing cart item
            CartModel cartItem;
            try
            {
                var existing = await _cartTable.GetEntityAsync<CartModel>(customerId, productId);
                cartItem = existing.Value;
                cartItem.QTY += qty; // update quantity
                cartItem.LastUpdatedDate = DateTime.UtcNow.AddHours(2);//Add hours to get to GMT +2 for RSA
            }
            catch (Azure.RequestFailedException ex) when (ex.Status == 404)
            {
                // Create a snapshot of product details, to freeze a snapshot of what the product details where when customer added that product
                var prod = product.Value;
                cartItem = new CartModel//(IIE Emeris School of Computer Science, 2025)
                {
                    PartitionKey = customerId,
                    RowKey = productId,
                    QTY = qty,
                    ProductNameSnapshot = prod.Name,
                    ProductDescriptionSnapshot = prod.Description,
                    ItemPriceSnapshot = prod.Price,
                    ImageUrlSnapshot = prod.ImageURL,
                    CreatedDate = DateTime.UtcNow.AddHours(2),//Add hours to get to GMT +2 for RSA,
                    LastUpdatedDate = DateTime.UtcNow.AddHours(2)//Add hours to get to GMT +2 for RSA
                };
            }

            // Upsert (insert or update)
            await _cartTable.UpsertEntityAsync(cartItem);
        }

        // GET CART ITEMS
        // Get all cart items for a customer
        public async Task<List<CartModel>> GetCartAsync(string customerId)
        {
            var results = new List<CartModel>();
            await foreach (var item in _cartTable.QueryAsync<CartModel>(x => x.PartitionKey == customerId))
            {
                results.Add(item);
            }
            return results;
        }

        // Clear Cart for a customer
        public async Task ClearCartAsync(string customerId)
        {
            var items = _cartTable.Query<CartModel>(x => x.PartitionKey == customerId);
            foreach (var item in items)
            {
                await _cartTable.DeleteEntityAsync(item.PartitionKey, item.RowKey);
            }
        }


        // Remove a single product from the cart
        public async Task RemoveFromCartAsync(string customerId, string productId)
        {
            await _cartTable.DeleteEntityAsync(customerId, productId);
        }
    }
}
