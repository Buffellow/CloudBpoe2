﻿using CLVD6212_ST10434337_ABCRetailer.Models;

namespace CLVD6212_ST10434337_ABCRetailer.Services
{
    public class LogService
    {
        /// <summary>
        /// Log when Order Status updates.. can use for other logs like in pt1 later
        /// </summary>
        private readonly TableStorageService<LogTableModel> _logTableService;

        public LogService(TableStorageService<LogTableModel> logTableService)//(IIE Emeris School of Computer Science, 2025)
        {
            _logTableService = logTableService;
        }

        public async Task WriteLogAsync(string orderId, OrderStatus status, string message, string actor)
        {
            var log = new LogTableModel
            {
                PartitionKey = orderId, // Group logs by OrderId
                RowKey = Guid.NewGuid().ToString(), // Unique log id
                EventStatus = status,// OrderPlaced, OrderDispached, OrderDelivered
                Message = message, // Description of Event like 'Order: OrderID was EventType by Admin AdminId'
                Actor = actor, // Customer, Admin or system
                CreatedDate = DateTime.UtcNow.AddHours(2)//Add hours to get to GMT +2 for RSA
            };

            await _logTableService.AddAsync(log);
        }
    }
}
