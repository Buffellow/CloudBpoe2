﻿using Azure.Storage.Blobs;
using Azure.Storage.Blobs.Models;

namespace CLVD6212_ST10434337_ABCRetailer.Services
{
    public class BlobService
    {
        private readonly BlobServiceClient _blobServiceClient;

        public BlobService(string connectionString)
        {
            _blobServiceClient = new BlobServiceClient(connectionString);
        }

        // Get or create container dynamically
        private BlobContainerClient GetContainerClient(string containerName)//(IIE Emeris School of Computer Science, 2025)
        {
            var containerClient = _blobServiceClient.GetBlobContainerClient(containerName);
            containerClient.CreateIfNotExists(PublicAccessType.Blob); // Creates if not found
            return containerClient;
        }

        // Upload
        // MAKE sure that in controller fileName is unique like ({Guid.NewGuid()}_{fileName})
        // Uploads FileSteam to container, overwrite flag replaces if file already exists
        public async Task<string> UploadBlobAsync(Stream fileStream, string fileName, string containerName)//(Microsoft, n.d.)
        {
            var containerClient = GetContainerClient(containerName);
            var blobClient = containerClient.GetBlobClient(fileName);
            await blobClient.UploadAsync(fileStream, overwrite: true);// Replace if file exists
            //Return URL of blob item
            return blobClient.Uri.ToString();
        }

        // Download
        public async Task<Stream?> DownloadBlobAsync(string fileName, string containerName)//(IIE Emeris School of Computer Science, 2025)
        {
            var containerClient = GetContainerClient(containerName);
            var blobClient = containerClient.GetBlobClient(fileName);

            if (await blobClient.ExistsAsync())
            {
                var response = await blobClient.DownloadAsync();
                //Return data stream of blob
                return response.Value.Content;
            }

            return null;
        }

        // Delete
        // Deletes specific blob via unique name, container Name. 
        public async Task DeleteBlobAsync(string fileName, string containerName)//(IIE Emeris School of Computer Science, 2025)
        {
            var containerClient = GetContainerClient(containerName);
            var blobClient = containerClient.GetBlobClient(fileName);
            // Delete if exists, delete blob item and all snapshots else it breaks 
            await blobClient.DeleteIfExistsAsync(DeleteSnapshotsOption.IncludeSnapshots);//(Microsoft, n.d.)
        }

        // List Blob Items
        public async Task<List<string>> ListBlobsAsync(string containerName)//(IIE Emeris School of Computer Science, 2025)
        {
            var containerClient = GetContainerClient(containerName);
            var blobNames = new List<string>();

            // loop through blob async..sly
            await foreach (var blob in containerClient.GetBlobsAsync())
            {
                blobNames.Add(blob.Name);
            }

            return blobNames;
        }
    }
}
