﻿using Azure.Storage.Queues;
using Azure.Storage.Queues.Models;

namespace CLVD6212_ST10434337_ABCRetailer.Services
{
    public class QueueService
    {
        private readonly QueueServiceClient _queueServiceClient;

        public QueueService(string connectionString)
        {
            _queueServiceClient = new QueueServiceClient(connectionString);
        }

        // Get or create queueName dynamically
        private QueueClient GetQueueClient(string queueName)//(IIE Emeris School of Computer Science, 2025)
        {
            var queueClient = _queueServiceClient.GetQueueClient(queueName);
            queueClient.CreateIfNotExists();
            return queueClient;
        }

        // Sends a JSON message to the specific queue
        public async Task SendMessageAsync(string queueName, string jsonMessage)//(Microsoft, 2023)
        {
            var queueClient = GetQueueClient(queueName);
            // Msg automatically encoded Base64 automatically (QueueClient)
            await queueClient.SendMessageAsync(jsonMessage);
        }

        // later, implement peeks... cant get it working after like 4 hours :(

        // Dequeue one message from the specified queue
        // Retrieved message becomes temporarily invisible to other consumers
        public async Task<QueueMessage> DequeueMessageAsync(string queueName)//(Microsoft, 2023)
        {
            var queueClient = GetQueueClient(queueName);
            var response = await queueClient.ReceiveMessageAsync();
            return response.Value;
        }

        // Dequeue one or more messages from the specified queue
        // Retrieved messages become temporarily invisible to other consumers
        public async Task<QueueMessage[]> DequeueMessagesAsync(string queueName, int maxMessages = 10)//(Microsoft, 2023)
        {
            var queueClient = GetQueueClient(queueName);

            if (maxMessages < 1 || maxMessages > 32)
            {
                throw new ArgumentException("maxMessages must be between 1 and 32", nameof(maxMessages));
            }

            var response = await queueClient.ReceiveMessagesAsync(maxMessages);
            return response.Value;
        }

        // Deletes a message from the queue
        public async Task DeleteMessageAsync(string queueName, string messageId, string popReceipt)//(Microsoft, 2023)
        {
            var queueClient = GetQueueClient(queueName);
            await queueClient.DeleteMessageAsync(messageId, popReceipt);
        }

        // Get amount of msgs in queueName
        public async Task<int> GetMessageCountAsync(string queueName)//(Microsoft, 2023)
        {
            var queueClient = GetQueueClient(queueName);
            //Get queue props for count
            var properties = await queueClient.GetPropertiesAsync();
            return properties.Value.ApproximateMessagesCount;
        }

        // Clear all msgs from queue
        public async Task ClearQueueAsync(string queueName)//(Microsoft, 2023)
        {
            var queueClient = GetQueueClient(queueName);
            // Clear msgs
            await queueClient.ClearMessagesAsync();
        }
    }
}
