﻿using Azure;
using Azure.Storage.Files.Shares;
using Azure.Storage.Files.Shares.Models;
using Azure.Storage.Sas;

namespace CLVD6212_ST10434337_ABCRetailer.Services
{
    public class FileShareService
    {
        private readonly ShareServiceClient _shareServiceClient;

        public FileShareService(string connectionString)
        {
            _shareServiceClient = new ShareServiceClient(connectionString);
        }

        // Get or create container dynamically
        private ShareClient GetShareClient(string shareName)//(IIE Emeris School of Computer Science, 2025)
        {
            var shareClient = _shareServiceClient.GetShareClient(shareName);
            shareClient.CreateIfNotExists(); // Creates if not found
            return shareClient;
        }

        // Upload
        // Uploads a file to the specific folder in shareName
        // Create folder if not exsist
        public async Task UploadFileAsync(string shareName, string folder, Stream fileStream, string fileName) //(Microsoft, 2025)
        {
            var shareClient = GetShareClient(shareName);

            // Navigate/create directory inside the share
            var directoryClient = shareClient.GetDirectoryClient(folder);
            directoryClient.CreateIfNotExists();

            // Get reference to the file in the directory
            var fileClient = directoryClient.GetFileClient(fileName);

            // get file size, compare, if size chaneg then upload new file
            // File share needs file to have size before I can upload. . . 
            await fileClient.CreateAsync(fileStream.Length); // allocate x MB of file size

            //Uplaod file data, for allocated file length/size
            await fileClient.UploadRangeAsync(new HttpRange(0, fileStream.Length), fileStream);
        }

        //Download
        // Downloads a file from the specific share and folder.
        public async Task<Stream?> DownloadFileAsync(string shareName, string folder, string fileName) //(Microsoft, 2025)
        {
            var shareClient = GetShareClient(shareName);
            var directoryClient = shareClient.GetDirectoryClient(folder);
            var fileClient = directoryClient.GetFileClient(fileName);

            if (await fileClient.ExistsAsync())
            {
                var downloadInfo = await fileClient.DownloadAsync();
                return downloadInfo.Value.Content; // Return file stream
            }

            return null;
        }

        // List Files
        // Lists all files inside a specified folder of a given share.
        public async Task<List<string>> ListFilesAsync(string shareName, string folder) //(Microsoft, 2025)
        {
            var shareClient = GetShareClient(shareName);
            var directoryClient = shareClient.GetDirectoryClient(folder);
            var fileNames = new List<string>();

            // loop through blob async..sly
            await foreach (ShareFileItem item in directoryClient.GetFilesAndDirectoriesAsync())
            {
                if (!item.IsDirectory)
                    fileNames.Add(item.Name);
            }

            return fileNames;
        }
        public string GetFileUri(string shareName, string folder, string fileName, TimeSpan? expiry = null)
        {
            var shareClient = GetShareClient(shareName);
            var directoryClient = shareClient.GetDirectoryClient(folder);
            var fileClient = directoryClient.GetFileClient(fileName);

            // Just the plain URI (not publicly usable unless you expose it)
            if (expiry == null)
                return fileClient.Uri.ToString();

            // With a SAS token (signed, temporary link)
            if (fileClient.CanGenerateSasUri)
            {
                var sasBuilder = new ShareSasBuilder
                {
                    ShareName = shareName,
                    FilePath = $"{folder}/{fileName}",
                    ExpiresOn = DateTimeOffset.UtcNow.Add(expiry.Value)
                };
                sasBuilder.SetPermissions(ShareFileSasPermissions.Read);

                Uri sasUri = fileClient.GenerateSasUri(sasBuilder);
                return sasUri.ToString();
            }

            throw new InvalidOperationException("SAS cannot be generated. Check client credentials.");
        }
    }
}
