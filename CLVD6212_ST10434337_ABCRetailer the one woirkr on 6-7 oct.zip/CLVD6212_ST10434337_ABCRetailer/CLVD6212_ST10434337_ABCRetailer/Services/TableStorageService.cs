﻿using Azure;
using Azure.Data.Tables;

namespace CLVD6212_ST10434337_ABCRetailer.Services
{
    /// <summary>
    /// Generic Service to interface for Azure Tables that allow me to use any model/table as log as it impliments ITableEntity.
	/// T represents the TypeofModel 
	/// Each TableName and Model is linked with singlton in Program.cs
    /// </summary>
    public class TableStorageService<T> where T : class, ITableEntity, new() //(Amor, 2017) & (Bro Code, 2021) & (IIE Emeris School of Computer Science, 2025)
    {
        private readonly TableClient _tableClient;

        // Creates a new instance of the service for a specific table and model type.
        public TableStorageService(string connectionString, string tableName)//(IIE Emeris School of Computer Science, 2025)
        {
            _tableClient = new TableClient(connectionString, tableName);
            _tableClient.CreateIfNotExists();
        }

        // Create/Add model/entity row to Table 
        public async Task AddAsync(T entity) //(Bro Code, 2021) & (IIE Emeris School of Computer Science, 2025)
        {
            //Validate that composite PK exists
            if (string.IsNullOrWhiteSpace(entity.PartitionKey) || string.IsNullOrWhiteSpace(entity.RowKey))
                throw new ArgumentException("PartitionKey and RowKey must be provided before adding the entity.");
            //Add Model/Entity to respective table
            await _tableClient.AddEntityAsync(entity);
        }

        // Read/Get list of all records from Table 
        public async Task<List<T>> GetAllAsync()//(Bro Code, 2021) & (IIE Emeris School of Computer Science, 2025)
        {
            var entities = new List<T>();
            await foreach (var entity in _tableClient.QueryAsync<T>())// QueryAsync explain please
            {
                entities.Add(entity);
            }
            return entities;
        }

        // Read/Get a single record from Table, use composite PK 
        public async Task<T?> GetSingleRecordAsync(string partitionKey, string rowKey)//(Bro Code, 2021) & (IIE Emeris School of Computer Science, 2025)
        {
            try
            {
                var response = await _tableClient.GetEntityAsync<T>(partitionKey, rowKey);
                return response.Value;
            }
            catch (RequestFailedException ex) when (ex.Status == 404)//(Microsoft, n.d.)
            {
                // Catch error in Controller when null, or do when not null. 
                return null;
            }
        }

        // Delete a record in a table 
        public async Task DeleteAsync(string partitionKey, string rowKey)//(Bro Code, 2021) & (IIE Emeris School of Computer Science, 2025)
        {
            await _tableClient.DeleteEntityAsync(partitionKey, rowKey);
        }

        // Query/Filter
        // Query entities with a filter Like ("PartitionKey eq 'Customers'")
        // If no filter string then send back all records
        public async Task<List<T>> QueryAsync(string filter)
        {
            var entities = new List<T>();
            await foreach (var entity in _tableClient.QueryAsync<T>(filter))//(Microsoft, n.d.)
            {
                entities.Add(entity);
            }
            return entities;
        }
    }
}
