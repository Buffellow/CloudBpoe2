﻿using Azure;
using Azure.Data.Tables;
using System.ComponentModel.DataAnnotations;
using System.Runtime.Serialization;

namespace CLVD6212_ST10434337_ABCRetailer.Models
{
    /// <summary>
    /// Customers Add Products to the Cart (snapshot of ProductModel at time of add)
    /// </summary>
    public class CartModel : ITableEntity
    {
        // Manditory 
        [Required]
        public string PartitionKey { get; set; }// CustomerID
        [Required]
        public string RowKey { get; set; } // ProductID
        [IgnoreDataMember]
        public DateTimeOffset? Timestamp { get; set; }
        [IgnoreDataMember]
        public ETag ETag { get; set; }

        //Own
        [Required]
        public string ProductNameSnapshot { get; set; }// Snapshot from ProductModel
        [Required]
        [Range(1, int.MaxValue, ErrorMessage = "Quantity must be 1 or greater")]
        public int QTY { get; set; }
        [Required]
        public string ProductDescriptionSnapshot { get; set; }
        [Required]
        [Range(0.01, (double)decimal.MaxValue, ErrorMessage = "Price must be greater than zero")]
        public decimal ItemPriceSnapshot { get; set; }

        public string ImageUrlSnapshot { get; set; }

        // Calculated (Qty * Price at time of add)
        public decimal ItemTotalAmount => QTY * ItemPriceSnapshot;
        public DateTime CreatedDate { get; set; }
        public DateTime LastUpdatedDate { get; set; }
        public CartModel()
        {
            // MUST set Partition, RowKey, Created Date in Controller
        }

    }
}
