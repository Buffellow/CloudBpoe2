﻿using Azure;
using Azure.Data.Tables;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Runtime.Serialization;

namespace CLVD6212_ST10434337_ABCRetailer.Models
{
    /// <summary>
    /// Admins can add/upload contracts, View the LogsTable
    /// </summary>
    public class AdminModel : ITableEntity
    {
        // Manditory 
        [Required]
        public string PartitionKey { get; set; } //GUID
        [Required]
        public string RowKey { get; set; }// Admin
        [IgnoreDataMember]
        public DateTimeOffset? Timestamp { get; set; }
        [IgnoreDataMember]
        public ETag ETag { get; set; }
        //Own
        [Display(Name = "Full Name")]
        [Required(ErrorMessage = "Full Name is required")]
        public string FullName { get; set; }
        [Display(Name = "Email")]
        [Required(ErrorMessage = "Email is required")]
        [EmailAddress(ErrorMessage = "Invalid email address")]
        public string Email { get; set; }// (Username)
        [Display(Name = "Created Date")]
        [DisplayFormat(ApplyFormatInEditMode = true, DataFormatString = "{0:MM/dd/yyyy}")]//(Fox,2011)
        public DateTime CreatedDate { get; set; }
        [Display(Name = "Username")]
        [Required(ErrorMessage = "Username is required")]
        public String Username { get; set; }
        [Display(Name = "Password")]
        [Required(ErrorMessage = "Password is required")]
        public string HashedPassword { get; set; }// use a viewModel to get password plain text 


        public AdminModel()
        {
            // MUST set Partition, RowKey, Created Date in Controller
        }
    }
}
