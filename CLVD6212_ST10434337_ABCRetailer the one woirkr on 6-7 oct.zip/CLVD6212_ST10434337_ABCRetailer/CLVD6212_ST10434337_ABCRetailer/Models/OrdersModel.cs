﻿using Azure;
using Azure.Data.Tables;
using System.ComponentModel.DataAnnotations;
using System.Runtime.Serialization;

namespace CLVD6212_ST10434337_ABCRetailer.Models
{
    /// <summary>
    /// Once a customer click place order, all items in cart become OrderItems and they form apart of a group of products ordered under this one Order made by the customer.
    /// After OrderItems, Order are created add a EventType (status) message to orderprocessing queue.
    /// Queue Service should pop msgs and add them to LogTableModel
    /// </summary>
    public enum OrderStatus 
    {
        OrderPlaced,
        OrderDispached,
        OrderDelivered

    }
    public class OrdersModel : ITableEntity
    {
        // Manditory 
        [Required]
        public string PartitionKey { get; set; }// CustomerID
        [Required]
        public string RowKey { get; set; }// GUID (as unique OrderID)
        [IgnoreDataMember]
        public DateTimeOffset? Timestamp { get; set; }
        [IgnoreDataMember]
        public ETag ETag { get; set; }
        // Own
        [Display(Name = "Customer Name")]
        public string CustomerID { get; set; }// FK to CustomerModel
        [Display(Name = "Date of Order")]
        [DisplayFormat(ApplyFormatInEditMode = true, DataFormatString = "{0:MM/dd/yyyy}")]//(Fox,2011)
        public DateTime OrderDate { get; set; }
        [Display(Name = "Order Status")]
        public OrderStatus Status { get; set; } // enum.ToString() 
        [Display(Name = "Total Amount")]
        public decimal TotalAmount { get; set; }// All Items in Order
        [Display(Name = "Created Date")]
        [DisplayFormat(ApplyFormatInEditMode = true, DataFormatString = "{0:MM/dd/yyyy}")]//(Fox,2011)
        public DateTime CreatedDate { get; set; }

        public OrdersModel()
        {
            // MUST set Partition, RowKey, Created Date in Controller
        }
    }
}
// refrence
/*
 Fox,D. 2011. Assign format of DateTime with data annotations? [Source code]. Avaliable at: https://stackoverflow.com/questions/5252979/assign-format-of-datetime-with-data-annotations [Accessed 7 October 2025]
(Fox,2011)
 
 */