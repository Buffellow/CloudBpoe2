﻿using Azure;
using Azure.Data.Tables;
using System.ComponentModel.DataAnnotations;
using System.Runtime.Serialization;

namespace CLVD6212_ST10434337_ABCRetailer.Models
{
    public class ProductModel : ITableEntity
    {
        // Manditory 
        [Required]
        public string PartitionKey { get; set; } //GUID
        [Required]
        public string RowKey { get; set; } // Product
        [IgnoreDataMember]
        public DateTimeOffset? Timestamp { get; set; }
        [IgnoreDataMember]
        public ETag ETag { get; set; }

        //Own
        [Display(Name = "Name")]
        [Required(ErrorMessage = "The Product Name is required")]
        public string Name { get; set; }
        [Display(Name = "Description")]
        [Required(ErrorMessage = "The Product Description is required")]
        public string Description { get; set; }
        [Display(Name = "Price per item")]
        [Required(ErrorMessage = "Price is required")]
        [Range(0.01, (double)decimal.MaxValue, ErrorMessage = "Price must be greater than zero")]
        public decimal Price { get; set; }
        [Display(Name = "Quantity")]
        [Required(ErrorMessage = "Quantity is required")]
        [Range(0, int.MaxValue, ErrorMessage = "Quantity must be a non-negative number")]
        public int StockQTY { get; set; }
        [Display(Name = "Image/Video")]
        public string ImageURL{ get; set; }// when empty dont display
        [Display(Name = "Created Date")]
        [DisplayFormat(ApplyFormatInEditMode = true, DataFormatString = "{0:MM/dd/yyyy}")]//(Fox,2011)
        public DateTime CreatedDate { get; set; }

        public ProductModel()
        {
            // MUST set Partition, RowKey, Created Date in Controller
        }

    }
}
