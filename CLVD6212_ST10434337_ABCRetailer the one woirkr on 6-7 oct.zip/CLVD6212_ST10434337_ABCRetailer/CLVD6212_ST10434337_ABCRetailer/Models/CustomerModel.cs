﻿using Azure;
using Azure.Data.Tables;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Runtime.Serialization;

namespace CLVD6212_ST10434337_ABCRetailer.Models
{
    public enum ContactMethod
    {
        Email,
        Phone,
        SMS
    }
    public class CustomerModel : ITableEntity
    {
        // Manditory 
        [Required]
        public string PartitionKey { get; set; } // GUID
        [Required]
        public string RowKey { get; set; } // Customer
        [IgnoreDataMember]
        public DateTimeOffset? Timestamp { get; set; }
        [IgnoreDataMember]
        public ETag ETag { get; set; }
        // Own
        [Display(Name = "Full Name")]
        [Required(ErrorMessage = "Full Name is required")]
        public string FullName{ get; set; }
        [Display(Name = "Email")]
        [Required(ErrorMessage = "Email is required")]
        [EmailAddress(ErrorMessage = "Invalid email address")]
        public string Email{ get; set; } // (Username)
        [Display(Name = "Phone")]
        [Required(ErrorMessage = "Phone is required")]
        [Phone(ErrorMessage = "Invalid phone number")]
        public string Phone{ get; set; }
        [Display(Name = "Preferred Contact Method")]
        [Required(ErrorMessage = "Contact method is required")]
        public ContactMethod PreferredContact { get; set; }
        [Display(Name = "Address")]
        [Required(ErrorMessage = "Address is required")]
        public string Address { get; set; }
        [Display(Name = "Created Date")]
        [DisplayFormat(ApplyFormatInEditMode = true, DataFormatString = "{0:MM/dd/yyyy}")]//(Fox,2011)
        public DateTime CreatedDate { get; set; }
        [Display(Name = "Username")]
        [Required(ErrorMessage = "Username is required")]
        public String Username { get; set; }
        [Display(Name = "Password")]
        [Required(ErrorMessage = "Password is required")]
        public string HashedPassword { get; set; }// use a viewModel to get password plain text 

        public CustomerModel()
        {
            // MUST set Partition, RowKey, Created Date in Controller
        }

    }
}
