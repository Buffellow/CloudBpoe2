﻿using Azure;
using Azure.Data.Tables;
using System.ComponentModel.DataAnnotations;
using System.Runtime.Serialization;

namespace CLVD6212_ST10434337_ABCRetailer.Models
{
    /// <summary>
    /// Each Product in Cart becoms a Order Item. 
    /// Orders cam be assigned to many OrderItems. 
    /// A group of order Items will be related to a specific OrderID. (this is a list of all items ordered, wher e Orders is the Order summary for each customers order.
    /// PartitionKey & RowKey form composite PK
    /// </summary>
    public class OrderItemsModel : ITableEntity
    {
        // Manditory 
        [Required]
        public string PartitionKey { get; set; }// OrderID FK
        [Required]
        public string RowKey { get; set; }// ProductID
        [IgnoreDataMember]
        public DateTimeOffset? Timestamp { get; set; }
        [IgnoreDataMember]
        public ETag ETag { get; set; }
        // Own
        [Display(Name = "Product Name")]
        [Required(ErrorMessage = "Username is required")]
        public string ProductName { get; set; }
        [Display(Name = "QTY")]
        [Required(ErrorMessage = "Full Name is required")]
        [Range(1, int.MaxValue, ErrorMessage = "Quantity must be 1 or greater")]
        public int QTY { get; set; }
        [Display(Name = "Price per item")]
        [Required(ErrorMessage = "Price is required")]
        [Range(0.01, (double)decimal.MaxValue, ErrorMessage = "Price must be greater than zero")]
        public decimal ItemPrice { get; set; }
        [Display(Name = "Sub-Total Amount")]
        public decimal TotalAmount { get; set; }// QTY * Price

    }
}
