﻿using System.Text.Json.Serialization;

namespace CLVD6212_ST10434337_ABCRetailer.Models
{
    /// <summary>
    /// Template for data in queue
    /// </summary>
    public class OrderQueueMessageModel
    {
        public string MessageId { get; set; } = Guid.NewGuid().ToString();
        public string OrderId { get; set; }
        public string CustomerId { get; set; }
        [JsonConverter(typeof(JsonStringEnumConverter))]
        public OrderStatus EventStatus { get; set; } // "OrderPlaced", "OrderDispatched", "OrderDelivered" //(Microsoft, n.d.)
        public object? Payload { get; set; } = null; // add other data when needed
        public DateTime Timestamp { get; set; } = DateTime.UtcNow;

        
    }
}
