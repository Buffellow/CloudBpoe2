﻿using System.ComponentModel.DataAnnotations;

namespace CLVD6212_ST10434337_ABCRetailer.Models
{
    public class LoginViewModelOLD
    {
        [EmailAddress]
        public string Username { get; set; }
        [DataType(DataType.Password)]
        public string Password { get; set; }
    }
}
