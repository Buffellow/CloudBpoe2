﻿using Azure;
using Azure.Data.Tables;
using System.ComponentModel.DataAnnotations;
using System.Runtime.Serialization;

namespace CLVD6212_ST10434337_ABCRetailer.Models
{
    /// <summary>
    /// LogTable is where orderprocessing queue deques and adds each message to the table where the admin can view log.
    /// I log status changes of an order 
    /// </summary>
    public class LogTableModel : ITableEntity
    {
        // Manditory 
        [Required]
        public string PartitionKey { get; set; }//OrderID 
        [Required]
        public string RowKey { get; set; }//LodID
        [IgnoreDataMember]
        public DateTimeOffset? Timestamp { get; set; }
        [IgnoreDataMember]
        public ETag ETag { get; set; }
        // Own
        public OrderStatus EventStatus{ get; set; } //enum.toString() 
        public string Message { get; set; } // Description of Event like 'Order: OrderID was EventType by Admin AdminId'
        public string Actor{ get; set; } //"User", "Admin", "System"
        public DateTime CreatedDate { get; set; } //{0:MM/dd/yyyy}
    }
}
