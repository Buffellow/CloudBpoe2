﻿using Azure;
using Azure.Data.Tables;
using System.ComponentModel.DataAnnotations;
using System.Runtime.Serialization;

namespace CLVD6212_ST10434337_ABCRetailer.Models
{
    /// <summary>
    /// Admin can create/upload contact, View Contracts List, View Selected Contract Details, Downlaod Selected Contract 
    /// </summary>
    public class ContractModel : ITableEntity
    {
        // Manditory 
        [Required]
        public string PartitionKey { get; set; }//GUID
        [Required]
        public string RowKey { get; set; }//Contract
        [IgnoreDataMember]
        public DateTimeOffset? Timestamp { get; set; }
        [IgnoreDataMember]
        public ETag ETag { get; set; }
        // Own
        [Display(Name = "File Name")]
        [Required(ErrorMessage = "File Name is required")]
        public string FileName { get; set; }
        [Display(Name = "Contract")]
        public string FileURL{ get; set; }
        [Display(Name = "Related To")]
        public string LinkedEntityID{ get; set; }//To what/who is this file related to (ProductID)
        [Display(Name = "Uploaded By")]
        public string UploadedBy{ get; set; }// ID of Admin who uploade contract (AdminID)
        [Display(Name = "Created Date")]
        [DisplayFormat(ApplyFormatInEditMode = true, DataFormatString = "{0:MM/dd/yyyy}")]//(Fox,2011)
        public DateTime CreatedDate { get; set; }


        public ContractModel()
        {
            // MUST set Partition, RowKey, Created Date in Controller
            // MUST link Which productID = LinkedEntityID
            // MUST link AdminID to uploade by
        }
    }
}
