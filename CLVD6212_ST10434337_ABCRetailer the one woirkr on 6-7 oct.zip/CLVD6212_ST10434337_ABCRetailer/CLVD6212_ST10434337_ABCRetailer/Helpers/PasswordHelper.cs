﻿namespace CLVD6212_ST10434337_ABCRetailer.Helpers
{
    /// <summary>
    /// See Project, BC is alias for BCrypt.Net.BCrypt
    /// https://claudiobernasconi.ch/blog/how-to-hash-passwords-with-bcrypt-in-csharp/
    /// </summary>
    public class PasswordHelper
    {
        // Hash a password
        public static string HashPassword(string password)
        {
            return BC.HashPassword(password);
        }

        // Verify a password
        public static bool VerifyPassword(string password, string hashedPassword)
        {
            return BC.Verify(password, hashedPassword);
        }
    }
}
